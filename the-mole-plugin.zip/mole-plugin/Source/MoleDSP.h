// The Mole - DSP core (Octaking Labs, Rev 0.1 voicing)
// Pure C++, no framework dependency, so it can be unit-tested anywhere.
// Signal chain (fixed order, like the pedal):
//   input trim -> [FUZZ: core A Soviet MP38A / core B US silicon] -> [KOT-style DRIVE]
//   -> [OUTPUT: presence + volume] -> out
// The whole chain runs 4x oversampled so the clipping stages stay clean.
#pragma once
#include <cmath>
#include <vector>
#include <algorithm>

namespace mole {

static constexpr double kPi = 3.14159265358979323846;

struct Params {
    float fuzz = 0.8f;      // 0..1
    float drive = 0.15f;    // 0..1
    float tone = 0.5f;      // 0..1
    float volume = 0.6f;    // 0..1
    float bias = 0.5f;      // 0..1 (0.5 = normal)
    float presence = 0.4f;  // 0..1
    bool  soviet = false;   // false = US silicon, true = Soviet MP38A
    bool  fuzzOn = true;
    bool  driveOn = true;
    int   mode = 1;         // 0 boost, 1 OD, 2 dist
    float inputTrimDb = 0.f;// -18..+18
};

// ---------------------------------------------------------------- filters
struct Biquad {
    double b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0, z1 = 0, z2 = 0;
    inline double process(double x) {
        double y = b0 * x + z1;
        z1 = b1 * x - a1 * y + z2;
        z2 = b2 * x - a2 * y;
        return y;
    }
    void reset() { z1 = z2 = 0; }
    void set(double nb0, double nb1, double nb2, double na0, double na1, double na2) {
        b0 = nb0 / na0; b1 = nb1 / na0; b2 = nb2 / na0; a1 = na1 / na0; a2 = na2 / na0;
    }
    void lowpass(double fs, double f, double q) {
        double w = 2 * kPi * f / fs, c = std::cos(w), al = std::sin(w) / (2 * q);
        set((1 - c) / 2, 1 - c, (1 - c) / 2, 1 + al, -2 * c, 1 - al);
    }
    void highpass(double fs, double f, double q) {
        double w = 2 * kPi * f / fs, c = std::cos(w), al = std::sin(w) / (2 * q);
        set((1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + al, -2 * c, 1 - al);
    }
    void peaking(double fs, double f, double q, double gDb) {
        double A = std::pow(10.0, gDb / 40), w = 2 * kPi * f / fs, c = std::cos(w), al = std::sin(w) / (2 * q);
        set(1 + al * A, -2 * c, 1 - al * A, 1 + al / A, -2 * c, 1 - al / A);
    }
    void highshelf(double fs, double f, double gDb) { // shelf slope S = 1
        double A = std::pow(10.0, gDb / 40), w = 2 * kPi * f / fs, c = std::cos(w);
        double al = std::sin(w) / 2 * std::sqrt((A + 1 / A) * (1 / 1.0 - 1) + 2);
        double sq = 2 * std::sqrt(A) * al;
        set(A * ((A + 1) + (A - 1) * c + sq), -2 * A * ((A - 1) + (A + 1) * c), A * ((A + 1) + (A - 1) * c - sq),
            (A + 1) - (A - 1) * c + sq, 2 * ((A - 1) - (A + 1) * c), (A + 1) - (A - 1) * c - sq);
    }
    void hp1(double fs, double f) { // first-order high-pass (bilinear)
        double k = std::tan(kPi * f / fs);
        b0 = 1 / (1 + k); b1 = -b0; b2 = 0; a1 = (k - 1) / (k + 1); a2 = 0;
    }
};

// ---------------------------------------------------------------- 4x oversampler (linear-phase FIR)
class Oversampler4x {
public:
    static constexpr int factor = 4;
    static constexpr int taps = 64;
    Oversampler4x() {
        h.resize(taps);
        double fc = 0.5 / factor * 0.9; // cutoff relative to oversampled rate
        double sum = 0;
        for (int i = 0; i < taps; ++i) {
            double n = i - (taps - 1) / 2.0;
            double sinc = n == 0 ? 2 * fc : std::sin(2 * kPi * fc * n) / (kPi * n);
            double win = 0.42 - 0.5 * std::cos(2 * kPi * i / (taps - 1)) + 0.08 * std::cos(4 * kPi * i / (taps - 1));
            h[i] = sinc * win; sum += h[i];
        }
        for (auto& v : h) v /= sum;
        reset();
    }
    void reset() { up.assign(taps, 0.0); dn.assign(taps, 0.0); upPos = dnPos = 0; }
    // latency in base-rate samples (two half-filters)
    static int latency() { return (taps - 1) / factor; }
    // push one base-rate sample, produce 4 oversampled samples
    void upsample(double x, double* out) {
        for (int p = 0; p < factor; ++p) {
            up[upPos] = (p == 0 ? x * factor : 0.0);
            double acc = 0; int idx = upPos;
            for (int k = 0; k < taps; ++k) { acc += h[k] * up[idx]; idx = (idx == 0 ? taps - 1 : idx - 1); }
            out[p] = acc;
            upPos = (upPos + 1) % taps;
        }
    }
    // consume 4 oversampled samples, produce one base-rate sample
    double downsample(const double* in) {
        double y = 0;
        for (int p = 0; p < factor; ++p) {
            dn[dnPos] = in[p];
            if (p == factor - 1) {
                int idx = dnPos;
                for (int k = 0; k < taps; ++k) { y += h[k] * dn[idx]; idx = (idx == 0 ? taps - 1 : idx - 1); }
            }
            dnPos = (dnPos + 1) % taps;
        }
        return y;
    }
private:
    std::vector<double> h, up, dn; int upPos = 0, dnPos = 0;
};

// ---------------------------------------------------------------- transistor voices (tuned against reference)
struct Voice { double gain, knee, asym, bias, even, hp, lp, fat; bool comp; };
static const Voice kUS  { 60, 3.0, 0.18, 0.06, -0.04, 95, 6500, 4, false };
static const Voice kSOV { 30, 1.6, 0.35, 0.12,  0.04, 70, 5200, 5, true  };

// ---------------------------------------------------------------- the pedal
class MolePedal {
public:
    void prepare(double sampleRate) {
        fs = sampleRate; fsO = fs * Oversampler4x::factor;
        updateFuzz(); updateDrive(); updateOut(); dirty = false;
        reset();
    }
    void reset() {
        for (auto* f : allFilters()) f->reset();
        compEnv = 0; dcX = dcY = 0; os.reset();
    }
    static int latencySamples() { return Oversampler4x::latency(); }

    void setParams(const Params& np) {
        bool voiceChanged = np.soviet != p.soviet || np.bias != p.bias || np.fuzz != p.fuzz;
        bool driveChanged = np.drive != p.drive || np.tone != p.tone || np.mode != p.mode;
        bool outChanged = np.presence != p.presence;
        p = np;
        if (voiceChanged || dirty) updateFuzz();
        if (driveChanged || dirty) updateDrive();
        if (outChanged || dirty) updateOut();
        dirty = false;
    }

    void process(float* data, int n) {
        const double inGain = std::pow(10.0, p.inputTrimDb / 20.0);
        const double vol = std::pow(p.volume / 0.6, 2.0);
        double buf[Oversampler4x::factor];
        for (int i = 0; i < n; ++i) {
            os.upsample(data[i] * inGain, buf);
            for (int k = 0; k < Oversampler4x::factor; ++k) {
                double x = buf[k];
                if (p.fuzzOn) x = fuzzTick(x);
                if (p.driveOn) x = driveTick(x);
                if (p.fuzzOn || p.driveOn) x = presence.process(x) * vol;
                buf[k] = x;
            }
            data[i] = (float) os.downsample(buf);
        }
    }

private:
    // ---------- fuzz
    double fuzzCurve(double x) const {
        x = std::clamp(x, -1.0, 1.0);
        double o = shape(fz.G * x + fz.b) - fz.f0;
        o = (o > 0 ? 1 : -1) * std::max(std::abs(o) - fz.gate, 0.0);
        return o / fz.norm;
    }
    double shape(double z) const {
        const Voice& v = *fz.v;
        double o = z >= 0 ? std::tanh(z * v.knee) / v.knee
                          : std::tanh(z * v.knee * (1 + v.asym)) / (v.knee * (1 + v.asym));
        return o + v.even * o * o;
    }
    void updateFuzz() {
        fz.v = p.soviet ? &kSOV : &kUS;
        fz.G = fz.v->gain * (0.15 + 0.85 * p.fuzz);
        fz.b = fz.v->bias + (p.bias - 0.5) * 0.6;
        fz.gate = std::max(0.0, 0.3 - p.bias) * 0.35;
        fz.f0 = shape(fz.b);
        double m = 1e-9;
        for (int i = 0; i <= 512; ++i) {
            double x = -1 + 2.0 * i / 512;
            double o = shape(fz.G * x + fz.b) - fz.f0;
            o = std::max(std::abs(o) - fz.gate, 0.0);
            m = std::max(m, o);
        }
        fz.norm = m;
        fHp.highpass(fsO, fz.v->hp, 0.707);
        fFat.peaking(fsO, 250, 0.8, fz.v->fat);
        fLp.lowpass(fsO, fz.v->lp, 0.707);
        // gentle "sag" compressor for germanium only
        compAtt = std::exp(-1.0 / (0.030 * fsO));
        compRel = std::exp(-1.0 / (0.250 * fsO));
    }
    double fuzzTick(double x) {
        x = fHp.process(x);
        if (fz.v->comp) { // ~1.8:1 above -18 dBFS, soft
            double a = std::abs(x);
            compEnv = a > compEnv ? compAtt * compEnv + (1 - compAtt) * a : compRel * compEnv + (1 - compRel) * a;
            double lvl = 20 * std::log10(compEnv + 1e-9), over = lvl + 18;
            if (over > 0) x *= std::pow(10.0, -over * (1 - 1 / 1.8) / 20);
        }
        x = fuzzCurve(x);
        // DC block
        double y = x - dcX + 0.9995 * dcY; dcX = x; dcY = y;
        y = fFat.process(y);
        y = fLp.process(y);
        return y * kFuzzLevel; // internal FUZZ LEVEL trim (RT2)
    }

    // ---------- KOT-style drive
    static double diodeFB(double u) { return u / std::pow(1 + std::pow(std::abs(u) / 0.55, 2.2), 1 / 2.2); }
    static double diodeGnd(double u) { return u / std::pow(1 + std::pow(std::abs(u) / 0.5, 4.0), 0.25); }
    static double rail(double u) { return 4 * std::tanh(u / 4); }
    void updateDrive() {
        dG1 = 0.3 + 70 * std::pow(p.drive, 2.2);
        dHp.highpass(fsO, 60, 0.6);
        dGHp.hp1(fsO, 723);
        dGLp.lowpass(fsO, 6500, 0.6);
        // TONE: Baxandall treble, SPICE range about -14 dB .. +10 dB
        double t = p.tone, g = t < 0.5 ? -14.0 * (1 - 2 * t) : 10.0 * (2 * t - 1);
        dTone.highshelf(fsO, 1400, g);
        dTreb.highshelf(fsO, 4500, 2.4);
    }
    double driveTick(double x) {
        x = dHp.process(x);
        double g = dGHp.process(x) * dG1;
        if (p.mode != 0) g = diodeFB(g);
        g = dGLp.process(g);
        double y = rail(x + g);
        if (p.mode == 2) y = diodeGnd(y) * 2;
        y = dTone.process(y);
        y = dTreb.process(y);
        return y * (p.mode == 2 ? 0.5 : 1.4 * 0.25);
    }

    // ---------- output
    void updateOut() { presence.highshelf(fsO, 3000, 1.5 + 6.0 * p.presence); }

    std::vector<Biquad*> allFilters() { return { &fHp, &fFat, &fLp, &dHp, &dGHp, &dGLp, &dTone, &dTreb, &presence }; }

    static constexpr double kFuzzLevel = 0.5;
    double fs = 48000, fsO = 192000;
    Params p; bool dirty = true;
    Oversampler4x os;
    struct { const Voice* v = &kUS; double G = 1, b = 0, gate = 0, f0 = 0, norm = 1; } fz;
    Biquad fHp, fFat, fLp, dHp, dGHp, dGLp, dTone, dTreb, presence;
    double compEnv = 0, compAtt = 0, compRel = 0, dcX = 0, dcY = 0, dG1 = 1;
};

} // namespace mole
