#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include "MoleDSP.h"

class MoleProcessor : public juce::AudioProcessor
{
public:
    MoleProcessor();
    ~MoleProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    using AudioProcessor::processBlock;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "The Mole"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return "Default"; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState apvts;
    std::atomic<float> inputPeak { 0.0f };

    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();

private:
    mole::MolePedal pedal;
    std::vector<float> mono;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (MoleProcessor)
};
