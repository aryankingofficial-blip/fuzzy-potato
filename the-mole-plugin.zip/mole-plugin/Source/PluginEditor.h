#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include "PluginProcessor.h"

class MoleLook : public juce::LookAndFeel_V4
{
public:
    MoleLook();
    void drawRotarySlider (juce::Graphics&, int x, int y, int w, int h, float pos,
                           float startAngle, float endAngle, juce::Slider&) override;
};

class FootSwitch : public juce::Button
{
public:
    explicit FootSwitch (const juce::String& name) : juce::Button (name) { setClickingTogglesState (true); }
    void paintButton (juce::Graphics&, bool over, bool down) override;
};

class BatToggle : public juce::Button
{
public:
    BatToggle() : juce::Button ("Transistors") { setClickingTogglesState (true); }
    void paintButton (juce::Graphics&, bool over, bool down) override;
};

class MoleEditor : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit MoleEditor (MoleProcessor&);
    ~MoleEditor() override;
    void paint (juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;
    using SA = juce::AudioProcessorValueTreeState::SliderAttachment;
    using BA = juce::AudioProcessorValueTreeState::ButtonAttachment;
    using CA = juce::AudioProcessorValueTreeState::ComboBoxAttachment;

    MoleProcessor& proc;
    MoleLook look;
    juce::Slider fuzz, drive, tone, volume, bias, presence, trim;
    juce::Label fuzzL, driveL, toneL, volumeL, biasL, presenceL, trimL, modeL;
    BatToggle soviet;
    FootSwitch fuzzOn { "Fuzz" }, driveOn { "Drive" };
    juce::ComboBox mode;
    std::vector<std::unique_ptr<SA>> sAtt;
    std::vector<std::unique_ptr<BA>> bAtt;
    std::unique_ptr<CA> cAtt;
    float meter = 0.0f;

    void setupKnob (juce::Slider&, juce::Label&, const juce::String& text, const juce::String& id, bool small);
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (MoleEditor)
};
