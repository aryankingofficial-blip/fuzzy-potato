#include "PluginProcessor.h"
#include "PluginEditor.h"

namespace
{
    std::unique_ptr<juce::AudioParameterFloat> knob (const juce::String& id, const juce::String& name, float def)
    {
        return std::make_unique<juce::AudioParameterFloat> (
            juce::ParameterID { id, 1 }, name, juce::NormalisableRange<float> (0.0f, 1.0f), def,
            juce::AudioParameterFloatAttributes().withStringFromValueFunction (
                [] (float v, int) { return juce::String (v * 10.0f, 1); }));
    }
}

juce::AudioProcessorValueTreeState::ParameterLayout MoleProcessor::createLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout l;
    // Defaults = the settings that measured closest to the reference
    l.add (knob ("fuzz", "Fuzz", 0.8f));
    l.add (knob ("drive", "Drive", 0.15f));
    l.add (knob ("tone", "Tone", 0.5f));
    l.add (knob ("volume", "Volume", 0.6f));
    l.add (knob ("bias", "Bias", 0.5f));
    l.add (knob ("presence", "Presence", 0.0f));
    l.add (std::make_unique<juce::AudioParameterBool> (juce::ParameterID { "soviet", 1 }, "Soviet MP38A", false));
    l.add (std::make_unique<juce::AudioParameterBool> (juce::ParameterID { "fuzzOn", 1 }, "Fuzz On", true));
    l.add (std::make_unique<juce::AudioParameterBool> (juce::ParameterID { "driveOn", 1 }, "Drive On", true));
    l.add (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID { "mode", 1 }, "Drive Mode",
                                                          juce::StringArray { "Boost", "OD", "Dist" }, 1));
    l.add (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { "inputTrim", 1 }, "Input Trim", juce::NormalisableRange<float> (-18.0f, 18.0f, 0.1f), 0.0f,
        juce::AudioParameterFloatAttributes().withLabel ("dB")));
    return l;
}

MoleProcessor::MoleProcessor()
    : AudioProcessor (BusesProperties()
                          .withInput ("Input", juce::AudioChannelSet::stereo(), true)
                          .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "MOLE", createLayout())
{
}

bool MoleProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto in = layouts.getMainInputChannelSet(), out = layouts.getMainOutputChannelSet();
    if (out != juce::AudioChannelSet::mono() && out != juce::AudioChannelSet::stereo())
        return false;
    if (in != juce::AudioChannelSet::mono() && in != juce::AudioChannelSet::stereo())
        return false;
    return in.size() <= out.size();
}

void MoleProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    pedal.prepare (sampleRate);
    mono.assign ((size_t) juce::jmax (1, samplesPerBlock), 0.0f);
    setLatencySamples (mole::MolePedal::latencySamples());
}

void MoleProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const int n = buffer.getNumSamples();
    const int inCh = getTotalNumInputChannels(), outCh = getTotalNumOutputChannels();
    if (n == 0 || inCh == 0) return;
    if ((int) mono.size() < n) mono.resize ((size_t) n);

    // Guitar is mono: average the input channels into one signal.
    float pk = 0.0f;
    for (int i = 0; i < n; ++i)
    {
        float s = 0.0f;
        for (int c = 0; c < inCh; ++c) s += buffer.getReadPointer (c)[i];
        s /= (float) inCh;
        mono[(size_t) i] = s;
        pk = juce::jmax (pk, std::abs (s));
    }
    inputPeak.store (juce::jmax (pk, inputPeak.load() * 0.9f));

    mole::Params p;
    p.fuzz = apvts.getRawParameterValue ("fuzz")->load();
    p.drive = apvts.getRawParameterValue ("drive")->load();
    p.tone = apvts.getRawParameterValue ("tone")->load();
    p.volume = apvts.getRawParameterValue ("volume")->load();
    p.bias = apvts.getRawParameterValue ("bias")->load();
    p.presence = apvts.getRawParameterValue ("presence")->load();
    p.soviet = apvts.getRawParameterValue ("soviet")->load() > 0.5f;
    p.fuzzOn = apvts.getRawParameterValue ("fuzzOn")->load() > 0.5f;
    p.driveOn = apvts.getRawParameterValue ("driveOn")->load() > 0.5f;
    p.mode = (int) apvts.getRawParameterValue ("mode")->load();
    p.inputTrimDb = apvts.getRawParameterValue ("inputTrim")->load();
    pedal.setParams (p);

    pedal.process (mono.data(), n);

    for (int c = 0; c < outCh; ++c)
        buffer.copyFrom (c, 0, mono.data(), n);
}

juce::AudioProcessorEditor* MoleProcessor::createEditor() { return new MoleEditor (*this); }

void MoleProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    if (auto xml = apvts.copyState().createXml())
        copyXmlToBinary (*xml, destData);
}

void MoleProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary (data, sizeInBytes))
        if (xml->hasTagName (apvts.state.getType()))
            apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new MoleProcessor(); }
