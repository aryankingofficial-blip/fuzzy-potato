#include "PluginEditor.h"

namespace col
{
    const juce::Colour oliveHi   { 0xff6a7049 };
    const juce::Colour olive     { 0xff4b5034 };
    const juce::Colour silk      { 0xffede6d3 };
    const juce::Colour brass     { 0xffb8893a };
    const juce::Colour brassHi   { 0xffe3c27d };
    const juce::Colour brassLo   { 0xff7d5c22 };
    const juce::Colour led       { 0xffd6402b };
    const juce::Colour ledOff    { 0xff4a2420 };
    const juce::Colour strip     { 0xff2b2e22 };
}

static juce::Font silkFont (float h, bool bold = true)
{
    return juce::Font (juce::FontOptions (h, bold ? juce::Font::bold : juce::Font::plain));
}

MoleLook::MoleLook()
{
    setColour (juce::Label::textColourId, col::silk);
    setColour (juce::ComboBox::backgroundColourId, col::strip.brighter (0.15f));
    setColour (juce::ComboBox::textColourId, col::silk);
    setColour (juce::ComboBox::outlineColourId, col::silk.withAlpha (0.4f));
    setColour (juce::ComboBox::arrowColourId, col::silk);
    setColour (juce::PopupMenu::backgroundColourId, col::strip);
    setColour (juce::PopupMenu::textColourId, col::silk);
    setColour (juce::Slider::textBoxTextColourId, col::silk);
    setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
}

void MoleLook::drawRotarySlider (juce::Graphics& g, int x, int y, int w, int h, float pos,
                                 float startAngle, float endAngle, juce::Slider&)
{
    auto area = juce::Rectangle<float> ((float) x, (float) y, (float) w, (float) h).reduced (4.0f);
    const float d = juce::jmin (area.getWidth(), area.getHeight());
    auto knob = area.withSizeKeepingCentre (d, d);
    const auto c = knob.getCentre();

    // tick ring
    g.setColour (col::silk.withAlpha (0.55f));
    for (int i = 0; i <= 10; ++i)
    {
        const float a = startAngle + (endAngle - startAngle) * (float) i / 10.0f;
        const float r1 = d * 0.5f, r2 = d * 0.5f - (i % 5 == 0 ? 6.0f : 3.5f);
        g.drawLine (c.x + r2 * std::sin (a), c.y - r2 * std::cos (a), c.x + r1 * std::sin (a), c.y - r1 * std::cos (a), 1.2f);
    }
    auto body = knob.reduced (d * 0.14f);
    g.setColour (juce::Colours::black.withAlpha (0.35f));
    g.fillEllipse (body.translated (0.0f, 3.0f));
    juce::ColourGradient grad (col::brassHi, body.getX() + body.getWidth() * 0.3f, body.getY() + body.getHeight() * 0.25f,
                               col::brassLo, body.getRight(), body.getBottom(), true);
    grad.addColour (0.45, col::brass);
    g.setGradientFill (grad);
    g.fillEllipse (body);
    // pointer
    const float a = startAngle + pos * (endAngle - startAngle);
    const float r = body.getWidth() * 0.5f;
    juce::Path p;
    p.addRoundedRectangle (-1.6f, -r + 3.0f, 3.2f, r * 0.55f, 1.5f);
    g.setColour (juce::Colour (0xff2a2112));
    g.fillPath (p, juce::AffineTransform::rotation (a).translated (c.x, c.y));
}

void FootSwitch::paintButton (juce::Graphics& g, bool over, bool down)
{
    auto b = getLocalBounds().toFloat();
    const bool on = getToggleState();
    // LED
    auto ledR = juce::Rectangle<float> (12.0f, 12.0f).withCentre ({ b.getCentreX(), b.getY() + 10.0f });
    if (on)
    {
        g.setColour (col::led.withAlpha (0.35f));
        g.fillEllipse (ledR.expanded (5.0f));
    }
    g.setColour (on ? col::led : col::ledOff);
    g.fillEllipse (ledR);
    // switch cap
    const float d = juce::jmin (b.getWidth(), b.getHeight() - 44.0f);
    auto cap = juce::Rectangle<float> (d, d).withCentre ({ b.getCentreX(), b.getY() + 28.0f + d * 0.5f });
    if (down) cap = cap.reduced (2.0f);
    g.setColour (juce::Colours::black.withAlpha (0.4f));
    g.fillEllipse (cap.translated (0.0f, 3.0f));
    juce::ColourGradient grad (juce::Colour (0xfff1f1f1), cap.getX() + cap.getWidth() * 0.3f, cap.getY() + cap.getHeight() * 0.3f,
                               juce::Colour (0xff5f6265), cap.getRight(), cap.getBottom(), true);
    grad.addColour (0.5, juce::Colour (0xff9a9da0));
    g.setGradientFill (grad);
    g.fillEllipse (cap);
    if (over) { g.setColour (juce::Colours::white.withAlpha (0.08f)); g.fillEllipse (cap); }
    g.setColour (col::silk);
    g.setFont (silkFont (14.0f));
    g.drawText (getName(), b.removeFromBottom (16.0f), juce::Justification::centred);
}

void BatToggle::paintButton (juce::Graphics& g, bool, bool)
{
    auto b = getLocalBounds().toFloat();
    const bool sov = getToggleState();
    g.setFont (silkFont (13.0f));
    auto left = b.removeFromLeft (b.getWidth() * 0.36f);
    auto right = b.removeFromRight (b.getWidth() * 0.56f);
    g.setColour (col::silk.withAlpha (sov ? 1.0f : 0.45f));
    g.drawFittedText (juce::String::fromUTF8 ("SOVIET\nМП38А"), left.toNearestInt(), juce::Justification::centred, 2);
    g.setColour (col::silk.withAlpha (sov ? 0.45f : 1.0f));
    g.drawFittedText ("US\nSILICON", right.toNearestInt(), juce::Justification::centred, 2);
    // bat toggle
    auto nut = juce::Rectangle<float> (18.0f, 18.0f).withCentre (b.getCentre());
    g.setColour (juce::Colour (0xff8d9093));
    g.fillEllipse (nut);
    g.setColour (juce::Colour (0xff3a3c3e));
    g.drawEllipse (nut, 1.2f);
    const float ang = sov ? -0.6f : 0.6f;
    juce::Path bat;
    bat.addRoundedRectangle (-3.0f, -20.0f, 6.0f, 20.0f, 3.0f);
    juce::ColourGradient grad (juce::Colour (0xfff4f4f4), -3.0f, 0.0f, juce::Colour (0xff8a8d90), 3.0f, 0.0f, false);
    g.setGradientFill (grad);
    g.fillPath (bat, juce::AffineTransform::rotation (ang).translated (nut.getCentreX(), nut.getCentreY()));
}

MoleEditor::MoleEditor (MoleProcessor& p) : juce::AudioProcessorEditor (&p), proc (p)
{
    setLookAndFeel (&look);
    setupKnob (fuzz, fuzzL, "FUZZ", "fuzz", false);
    setupKnob (drive, driveL, "DRIVE", "drive", false);
    setupKnob (tone, toneL, "TONE", "tone", false);
    setupKnob (volume, volumeL, "VOLUME", "volume", false);
    setupKnob (bias, biasL, "BIAS", "bias", true);
    setupKnob (presence, presenceL, "PRESENCE", "presence", true);
    setupKnob (trim, trimL, "INPUT TRIM", "inputTrim", true);
    trim.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 60, 16);

    for (auto* b : { (juce::Button*) &soviet, (juce::Button*) &fuzzOn, (juce::Button*) &driveOn })
        addAndMakeVisible (b);
    bAtt.push_back (std::make_unique<BA> (proc.apvts, "soviet", soviet));
    bAtt.push_back (std::make_unique<BA> (proc.apvts, "fuzzOn", fuzzOn));
    bAtt.push_back (std::make_unique<BA> (proc.apvts, "driveOn", driveOn));

    mode.addItemList ({ "Boost", "OD", "Dist" }, 1);
    addAndMakeVisible (mode);
    cAtt = std::make_unique<CA> (proc.apvts, "mode", mode);
    modeL.setText ("DRIVE MODE", juce::dontSendNotification);
    modeL.setFont (silkFont (11.0f));
    modeL.setJustificationType (juce::Justification::centred);
    addAndMakeVisible (modeL);

    setSize (560, 470);
    startTimerHz (30);
}

MoleEditor::~MoleEditor() { setLookAndFeel (nullptr); }

void MoleEditor::setupKnob (juce::Slider& s, juce::Label& l, const juce::String& text, const juce::String& id, bool small)
{
    s.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    s.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
    s.setRotaryParameters (juce::MathConstants<float>::pi * 1.25f, juce::MathConstants<float>::pi * 2.75f, true);
    s.setPopupDisplayEnabled (true, true, this);
    addAndMakeVisible (s);
    sAtt.push_back (std::make_unique<SA> (proc.apvts, id, s));
    l.setText (text, juce::dontSendNotification);
    l.setFont (silkFont (small ? 11.0f : 14.0f));
    l.setJustificationType (juce::Justification::centred);
    addAndMakeVisible (l);
}

void MoleEditor::paint (juce::Graphics& g)
{
    auto b = getLocalBounds().toFloat();
    auto strip = b.removeFromBottom (92.0f);
    g.setColour (col::strip);
    g.fillRect (strip);
    juce::ColourGradient grad (col::oliveHi, 0.0f, 0.0f, col::olive, b.getRight(), b.getBottom(), false);
    g.setGradientFill (grad);
    g.fillRect (b);
    g.setColour (juce::Colours::black.withAlpha (0.25f));
    for (auto pt : { juce::Point<float> { 14, 14 }, { b.getRight() - 14, 14 }, { 14, b.getBottom() - 14 }, { b.getRight() - 14, b.getBottom() - 14 } })
        g.fillEllipse (juce::Rectangle<float> (8, 8).withCentre (pt));

    g.setColour (col::silk);
    g.setFont (silkFont (34.0f));
    g.drawText ("THE MOLE", 24, 16, 300, 40, juce::Justification::left);
    g.setFont (silkFont (12.0f, false));
    g.drawText ("Fuzz into King of Tone-style drive", 26, 52, 300, 18, juce::Justification::left);
    g.drawText ("OCTAKING LABS", getWidth() - 200, 24, 176, 20, juce::Justification::right);

    // internal strip
    g.setColour (col::silk.withAlpha (0.6f));
    g.setFont (silkFont (11.0f));
    g.drawText ("INSIDE THE PEDAL", 20, (int) strip.getY() + 8, 200, 14, juce::Justification::left);
    // input meter
    auto m = juce::Rectangle<float> (strip.getRight() - 150, strip.getY() + 30, 120, 10);
    g.setColour (juce::Colours::black.withAlpha (0.5f));
    g.fillRoundedRectangle (m, 3.0f);
    const float db = juce::Decibels::gainToDecibels (meter, -60.0f);
    const float frac = juce::jlimit (0.0f, 1.0f, (db + 60.0f) / 60.0f);
    g.setColour (db > -3.0f ? col::led : col::brass);
    g.fillRoundedRectangle (m.withWidth (m.getWidth() * frac), 3.0f);
    g.setColour (col::silk.withAlpha (0.8f));
    g.setFont (silkFont (11.0f, false));
    g.drawText ("INPUT  " + juce::String (db, 1) + " dB", (int) m.getX(), (int) m.getBottom() + 4, 120, 14, juce::Justification::left);
    g.drawText ("aim for -12 to -6 dB peaks", (int) m.getX(), (int) m.getBottom() + 18, 150, 14, juce::Justification::left);
}

void MoleEditor::resized()
{
    auto b = getLocalBounds();
    auto strip = b.removeFromBottom (92);
    b.removeFromTop (78);
    auto row = b.removeFromTop (130).reduced (16, 0);
    const int w = row.getWidth() / 4;
    juce::Slider* big[] = { &fuzz, &drive, &tone, &volume };
    juce::Label* bigL[] = { &fuzzL, &driveL, &toneL, &volumeL };
    for (int i = 0; i < 4; ++i)
    {
        auto cell = row.removeFromLeft (w);
        bigL[i]->setBounds (cell.removeFromBottom (20));
        big[i]->setBounds (cell.reduced (8, 0));
    }
    auto mid = b.removeFromTop (70).reduced (40, 0);
    auto l = mid.removeFromLeft (90); biasL.setBounds (l.removeFromBottom (16)); bias.setBounds (l);
    auto r = mid.removeFromRight (90); presenceL.setBounds (r.removeFromBottom (16)); presence.setBounds (r);
    soviet.setBounds (mid.withSizeKeepingCentre (220, 56));
    auto feet = b.reduced (60, 4);
    fuzzOn.setBounds (feet.removeFromLeft (110));
    driveOn.setBounds (feet.removeFromRight (110));

    auto s = strip.reduced (16, 0);
    s.removeFromTop (26);
    auto mc = s.removeFromLeft (130);
    modeL.setBounds (mc.removeFromTop (14));
    mode.setBounds (mc.removeFromTop (26));
    s.removeFromLeft (30);
    auto tc = s.removeFromLeft (90);
    trimL.setBounds (tc.removeFromTop (14).translated (0, -2));
    trim.setBounds (tc);
}

void MoleEditor::timerCallback()
{
    meter = proc.inputPeak.load();
    repaint (getWidth() - 180, getHeight() - 92, 180, 92);
}
