// Offline test: run a mono 16-bit WAV through the Mole DSP core.
#include "../Source/MoleDSP.h"
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <string>
int main(int argc,char**argv){
  if(argc<4){printf("usage: render in.wav out.wav key=val...\n");return 1;}
  FILE*f=fopen(argv[1],"rb"); std::vector<uint8_t> d; uint8_t b[65536]; size_t n;
  while((n=fread(b,1,sizeof b,f))>0) d.insert(d.end(),b,b+n); fclose(f);
  size_t pos=12; uint32_t sr=48000; int16_t* pcm=nullptr; uint32_t bytes=0; int ch=1;
  while(pos+8<=d.size()){ uint32_t sz; memcpy(&sz,&d[pos+4],4);
    if(!memcmp(&d[pos],"fmt ",4)){ uint16_t c; memcpy(&c,&d[pos+10],2); ch=c; memcpy(&sr,&d[pos+12],4);}
    if(!memcmp(&d[pos],"data",4)){ pcm=(int16_t*)&d[pos+8]; bytes=sz; break;}
    pos+=8+sz+(sz&1);}
  size_t N=bytes/2/ch; std::vector<float> x(N);
  for(size_t i=0;i<N;i++) x[i]=pcm[i*ch]/32768.f;
  mole::Params p; float gvol=1;
  for(int i=3;i<argc;i++){ std::string a=argv[i]; auto e=a.find('='); std::string k=a.substr(0,e); float v=atof(a.c_str()+e+1);
    if(k=="fuzz")p.fuzz=v; else if(k=="drive")p.drive=v; else if(k=="tone")p.tone=v; else if(k=="vol")p.volume=v;
    else if(k=="bias")p.bias=v; else if(k=="presence")p.presence=v; else if(k=="soviet")p.soviet=v>0;
    else if(k=="fuzzOn")p.fuzzOn=v>0; else if(k=="driveOn")p.driveOn=v>0; else if(k=="mode")p.mode=(int)v; else if(k=="gvol")gvol=v; }
  float g=std::pow(gvol,1.6f); for(auto&s:x) s*=g;
  mole::MolePedal m; m.prepare(sr); m.setParams(p);
  for(size_t i=0;i<N;i+=512) m.process(x.data()+i,(int)std::min<size_t>(512,N-i));
  float pk=0; for(auto s:x) pk=std::max(pk,std::abs(s));
  FILE*o=fopen(argv[2],"wb"); uint32_t ds=N*4, rs=36+ds; uint16_t fmt=3,c1=1,ba=4,bps=32; uint32_t br=sr*4, fs16=16;
  fwrite("RIFF",1,4,o);fwrite(&rs,4,1,o);fwrite("WAVEfmt ",1,8,o);fwrite(&fs16,4,1,o);fwrite(&fmt,2,1,o);fwrite(&c1,2,1,o);
  fwrite(&sr,4,1,o);fwrite(&br,4,1,o);fwrite(&ba,2,1,o);fwrite(&bps,2,1,o);fwrite("data",1,4,o);fwrite(&ds,4,1,o);fwrite(x.data(),4,N,o);fclose(o);
  printf("rendered %zu samples, peak %.3f, latency %d\n",N,pk,mole::MolePedal::latencySamples());
}
