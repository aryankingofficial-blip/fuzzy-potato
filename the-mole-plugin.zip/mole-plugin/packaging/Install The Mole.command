#!/bin/bash
# Installs The Mole (Audio Unit for Logic Pro + VST3) for the current user.
cd "$(dirname "$0")"
AU=~/Library/Audio/Plug-Ins/Components
VST=~/Library/Audio/Plug-Ins/VST3
mkdir -p "$AU" "$VST"
rm -rf "$AU/The Mole.component" "$VST/The Mole.vst3"
cp -R "The Mole.component" "$AU/"
cp -R "The Mole.vst3" "$VST/"
xattr -dr com.apple.quarantine "$AU/The Mole.component" "$VST/The Mole.vst3" 2>/dev/null
killall -9 AudioComponentRegistrar 2>/dev/null
echo ""
echo "The Mole is installed."
echo "Open Logic Pro. If it was already open, quit and reopen it."
echo "Find it on a track under: Audio Units > Octaking Labs > The Mole"
echo ""
read -n 1 -s -r -p "Press any key to close this window."
